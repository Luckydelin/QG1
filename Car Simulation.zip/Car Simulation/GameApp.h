#ifndef GAMEAPP_H
#define GAMEAPP_H

#include "d3dApp.h"
#include "GameObject.h"
#include "SkyRender.h"
#include "ObjReader.h"
#include "Collision.h"
#pragma comment(lib,"winmm.lib")

class GameApp : public D3DApp
{
public:
	// 摄像机模式
	enum class CameraMode { ThirdPerson, Free };

	// 天空盒模式
	enum class SkyBoxMode { Dusk, Afternoon,Day };
public:
	GameApp(HINSTANCE hInstance);
	~GameApp();

	bool Init();
	void OnResize();
	void UpdateScene(float dt);
	void DrawScene();

private:
	bool InitResource();

	void DrawScene(bool drawCenterSphere);

private:


	float m_Eta;												// 空气/介质折射率


	std::shared_ptr<Camera> m_pCamera;						    // 摄像机
	CameraMode m_CameraMode;									// 摄像机模式

	SkyBoxMode m_SkyBoxMode;									// 天空盒模式

	ObjReader m_ObjReader;									    // 模型读取对象

	//光源
	SpotLight m_FrontLight;										//前灯
	SpotLight m_FrontLightL;									//前左灯
	SpotLight m_FrontLightR;									//前右灯
	SpotLight m_BackLightL;										//后左灯
	SpotLight m_BackLightR;										//后右灯

	GameObject m_Ground;										// 地面
	GameObject m_GroundT;										// 地面法线贴图
	GameObject m_Road;											//公路
	GameObject m_RoadT;											//公路法线贴图

	GameObject m_ftyreL;									    // 前左车轮
	GameObject m_ftyreR;										// 前右车轮
	GameObject m_btyreL;										// 后左车轮
	GameObject m_btyreR;										// 后右车轮

	GameObject m_FrameL;										//左镜柄
	GameObject m_FrameR;										//右镜柄
	GameObject m_car;											//车身

	GameObject m_fLightL;										//前灯
	GameObject m_fLightR;
	GameObject m_bLightL;										//后灯
	GameObject m_bLightR;

	GameObject m_mirrorL;										// 镜面
	GameObject m_mirrorR;

	std::vector<Transform> m_TreeWorlds;						//树的SRT
	GameObject m_Trees;											//树

	std::vector<Transform> m_FenceWorlds;						//围栏的SRT
	GameObject m_Fences;										//围栏

	BasicEffect m_BasicEffect;								    // 对象渲染特效管理
	SkyEffect m_SkyEffect;										// 天空盒特效管理

	
	std::unique_ptr<DynamicSkyRender> m_pDusk;						// 天空盒(黄昏)
	std::unique_ptr<DynamicSkyRender> m_pAfternoon;						// 天空盒(下午)
	std::unique_ptr<DynamicSkyRender> m_pDay;						// 天空盒(白天)

	Material m_ShadowMat;											//阴影材质
	Material m_CarMat;												//车身材质

	


	float m_FogRange;										    // 雾效范围

	ComPtr<ID3D11ShaderResourceView> m_GroundNormalMap;		    // 草地法线贴图
	ComPtr<ID3D11ShaderResourceView> m_RoadNormalMap;		    // 公路法线贴图

	bool m_NormalMapEnabled;									 // 是否开启法线贴图
	bool m_FogEnabled;										    // 是否开启雾效
	bool m_NightEnabled;											    // 是否黑夜


	DirectionalLight m_dirLight[4];								//环境光

	bool m_IsNight;												//是否为黑夜
};


#endif