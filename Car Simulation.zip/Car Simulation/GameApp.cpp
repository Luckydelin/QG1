#include "GameApp.h"
#include "d3dUtil.h"
#include "DXTrace.h"
#include <Windows.h>

using namespace DirectX;

std::vector<BoundingBox>  m_ISBounding;

GameApp::GameApp(HINSTANCE hInstance)
	: D3DApp(hInstance),
	m_CameraMode(CameraMode::Free),
	m_NormalMapEnabled(true),
	m_FogEnabled(false),
	m_NightEnabled(true),
	m_IsNight(false),
	 m_Eta(1.5/1),
	m_FrontLight(),
	m_fLightL(),
	m_CarMat(),
	m_BackLightR(),
	m_BackLightL(),
	m_dirLight(),
	m_SkyBoxMode(SkyBoxMode::Day),
	m_ShadowMat(),
	m_FrontLightR(),
	m_FrontLightL(),
	m_FogRange()
{

}



GameApp::~GameApp()
{
}

bool GameApp::Init()
{
	if (!D3DApp::Init())
		return false;

	// 务必先初始化所有渲染状态，以供下面的特效使用
	RenderStates::InitAll(m_pd3dDevice.Get());

	if (!m_BasicEffect.InitAll(m_pd3dDevice.Get()))
		return false;

	if (!m_SkyEffect.InitAll(m_pd3dDevice.Get()))
		return false;

	if (!InitResource())
		return false;

	// 初始化鼠标，键盘不需要
	m_pMouse->SetWindow(m_hMainWnd);
	m_pMouse->SetMode(DirectX::Mouse::MODE_ABSOLUTE);

	return true;
}

void GameApp::OnResize()
{
	assert(m_pd2dFactory);
	assert(m_pdwriteFactory);
	

	D3DApp::OnResize();

	

	// 摄像机变更显示
	if (m_pCamera != nullptr)
	{
		m_pCamera->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
		m_pCamera->SetViewPort(0.0f, 0.0f, (float)m_ClientWidth, (float)m_ClientHeight);
		m_BasicEffect.SetProjMatrix(m_pCamera->GetProjXM());
	}
}

void GameApp::UpdateScene(float dt)
{
	ImGuiIO& io = ImGui::GetIO();

	//获取摄像机子类
	auto cam1st = std::dynamic_pointer_cast<FirstPersonCamera>(m_pCamera);

	static float fontsize = 30.0f;//字体大小


	

	//昼夜更替
	static int Time=4000;
	if (m_NightEnabled)
	{
		int Light = 0,LightNum;
		for ( LightNum = Time / 1000; Light <LightNum; Light++)
		{
			m_BasicEffect.SetDirLight(Light, m_dirLight[Light]);
		}
		switch (Light)
		{
		case 0:m_IsNight = true; break;
		case 1: m_IsNight = false; m_SkyBoxMode = SkyBoxMode::Dusk; break;
		case 2:m_IsNight = false; m_SkyBoxMode = SkyBoxMode::Dusk; break;
		case 3:m_IsNight = false; m_SkyBoxMode = SkyBoxMode::Afternoon; break;
		case 4:m_IsNight = false; m_SkyBoxMode = SkyBoxMode::Day; break;
		}

		while (Light <4)
		{
			m_BasicEffect.SetDirLight(Light, DirectionalLight());
			Light++;
		}
		static bool div=false;
		if (div==true)
		{
			Time--;
			if (Time == 0)
				div = false;
		}
		if (div==false)
		{
			Time++;
			if (Time == 4999)
				div = true;
		}
	}
	//是否法线贴图
	if (ImGui::IsKeyReleased('1'))
	{
		m_NormalMapEnabled = !m_NormalMapEnabled;
	}
	//是否雾天
	if (ImGui::IsKeyReleased('2'))
	{
		m_FogEnabled = !m_FogEnabled;
		m_BasicEffect.SetFogState(m_FogEnabled);
	}

	static float speed = 0;
	if (m_CameraMode == CameraMode::ThirdPerson || m_CameraMode == CameraMode::Free)
	{

		// 第一人称/自由摄像机的操作
		static float d1 = 0.0f;
		float d2 = 0.0f;
		
		//自由摄像机的移动---d
		float d=0;

		if (ImGui::IsKeyDown('W'))
		{
			d1 += dt;
			d += dt;
		}
		else if (ImGui::IsKeyDown('S'))
		{
			d1 -= dt;
			d -= dt;
		}
		else
			d1 /= 1.002;

		if (ImGui::IsKeyDown('A'))
			d2 -= dt;
		if (ImGui::IsKeyDown('D'))
			d2 += dt;

		if (d1 > 0.03)
			d1 = 0.03;
		else if (d1 < -0.03)
			d1 = -0.03;

		static	float d3 ;
		d3 += d2;

		if (m_CameraMode == CameraMode::ThirdPerson)	
		{
			//引擎声
			if (ImGui::IsKeyReleased('W'))
			{
				PlaySound(L"funtion.wav", NULL, SND_FILENAME | SND_ASYNC );
			}
			
			//喇叭
			if (ImGui::IsKeyReleased('R'))
			{
				PlaySound(L"horn.wav", NULL, SND_FILENAME | SND_ASYNC);
			}
			//点火/熄火
			if (ImGui::IsKeyReleased('F'))
			{
				if (speed == 0)
				{
					PlaySound(L"OpenEngine.wav", NULL, SND_FILENAME | SND_ASYNC);
					speed = 1;
				}
				else
				{
					PlaySound(L"lock.wav", NULL, SND_FILENAME | SND_ASYNC);
					speed = 0;
				}

			}
			//进档
			if (ImGui::IsKeyReleased('Q'))
			{
				speed += 1;
				if (speed >= 6)
					speed = 6;
			}
			//退档
			if (ImGui::IsKeyReleased('E'))
			{
				speed -= 1;
				if (speed <= 0)
					speed = 1;
			}
			//刹车
			if (ImGui::IsKeyDown(ImGuiKey_Space))
			{
				speed /= 1.01;
				if (speed < 0)
					speed = 0;
				m_BackLightL.direction = XMFLOAT3(0.0f, 0.0f, -1.0f);
				m_BackLightL.ambient = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_BackLightL.diffuse = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_BackLightL.specular = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_BackLightL.att = XMFLOAT3(1.0f, 0.0f, 0.0f);
				m_BackLightL.spot = 5.0f;
				m_BackLightL.range = 5.0f;
				m_BackLightR = m_BackLightL;
				XMFLOAT3 lightpos1 = m_bLightL.GetTransform().GetPosition();
				XMFLOAT3 lightpos2 = m_bLightR.GetTransform().GetPosition();
				m_BackLightL.position = XMFLOAT3(lightpos1.x, lightpos1.y, lightpos1.z + 2);
				m_BackLightR.position = XMFLOAT3(lightpos2.x, lightpos2.y, lightpos2.z + 2);

				m_BasicEffect.SetSpotLight(2, m_BackLightL);
				m_BasicEffect.SetSpotLight(3, m_BackLightR);
			}
			else
			{
				m_BasicEffect.SetSpotLight(2, SpotLight());
				m_BasicEffect.SetSpotLight(3, SpotLight());
			}
			//刹车声
			if (ImGui::IsKeyReleased(ImGuiKey_Space))
			{
				PlaySound(L"brake.wav", NULL, SND_FILENAME | SND_ASYNC);
			}
			//检测小车是否与围栏相碰
			XMFLOAT3 ftyreposL = m_ftyreL.GetTransform().GetPosition();
			Ray ray1 = Ray(m_ftyreL.GetTransform().GetPosition(), m_ftyreL.GetTransform().GetRightAxis());
			Ray ray2 = Ray(m_ftyreR.GetTransform().GetPosition(), m_ftyreR.GetTransform().GetRightAxis());
			static bool IsHit = 0;
			for (int i = 0; i < m_ISBounding.size(); i++)
			{
				if (ray1.Hit(m_ISBounding[i]) )
				{
					m_ftyreL.GetTransform().SetPosition(ftyreposL.x+0.1, ftyreposL.y, ftyreposL.z);
					IsHit = true;	
					break;
				}
				if (ray2.Hit(m_ISBounding[i]))
				{
					m_ftyreL.GetTransform().SetPosition(ftyreposL.x - 0.1, ftyreposL.y, ftyreposL.z);
					IsHit = true;
					break;
				}
				IsHit = false;
			}
			//没有碰撞就允许加油门
			if (IsHit == false)
			{
				if (d1 < 0 && speed == 1)
				{
					m_ftyreL.GetTransform().Translate(m_ftyreL.GetTransform().GetForwardAxis(), d1 * speed);
				}
				else if(d1>0)
				{
					m_ftyreL.GetTransform().Translate(m_ftyreL.GetTransform().GetForwardAxis(), d1 * speed);
				}
			}
			//车子的定位
			m_ftyreR.GetTransform().SetPosition(ftyreposL.x + 2.1, ftyreposL.y, ftyreposL.z);
			m_car.GetTransform().SetPosition(ftyreposL.x + 1.05, ftyreposL.y + 0.5, ftyreposL.z - 1.5);

			XMFLOAT3 carpos = m_car.GetTransform().GetPosition();
			m_btyreL.GetTransform().SetPosition(carpos.x - 1.05f, carpos.y - 0.5f, carpos.z - 1.5f);
			m_btyreR.GetTransform().SetPosition(carpos.x + 1.05, carpos.y - 0.5f, carpos.z - 1.5f);
			m_fLightL.GetTransform().SetPosition(carpos.x - 0.75f, carpos.y + 0.3, carpos.z + 2.05f);
			m_fLightR.GetTransform().SetPosition(carpos.x + 0.75f, carpos.y + 0.3, carpos.z + 2.05f);

			m_bLightL.GetTransform().SetPosition(carpos.x - 0.75f, carpos.y + 0.3, carpos.z - 2.05f);
			m_bLightR.GetTransform().SetPosition(carpos.x + 0.75f, carpos.y + 0.3, carpos.z - 2.05f);

			//镜柄的定位
			m_FrameL.GetTransform().SetPosition(carpos.x - 0.84f, carpos.y + 0.2, carpos.z + 0.9f);
			m_FrameR.GetTransform().SetPosition(carpos.x + 0.84f, carpos.y + 0.2, carpos.z + 0.9f);

			//车轮的旋转
			m_ftyreL.GetTransform().SetRotation(0.0f, d3 * 2.0f, XM_PIDIV2);
			m_ftyreR.GetTransform().SetRotation(0.0f, d3 * 2.0f, XM_PIDIV2);

			m_btyreL.GetTransform().SetRotation(d1 * speed*XM_2PI, 0.0f, XM_PIDIV2);
			m_btyreR.GetTransform().SetRotation(d1 * speed* XM_2PI, 0.0f, XM_PIDIV2);

			//小车视角的切换
			static int View=1;
			if (ImGui::IsKeyReleased('V'))
			{
				View++;
				if (View > 3)
					View = 1;
			}
			switch (View)
			{
			case 1:cam1st->SetPosition(carpos.x, carpos.y+1, carpos.z + 2.0); break;
			case 2:cam1st->SetPosition(carpos.x, carpos.y + 3, carpos.z - 8); break;
			case 3:cam1st->SetPosition(carpos.x, carpos.y + 3, carpos.z - 12.0); break;
			}

			//前向灯光
			static int Flight = 0;

			//关灯
			if (ImGui::IsKeyDown('L') && (Flight == 1 || Flight == 2))
			{
				m_FrontLightL = SpotLight();
				m_FrontLightR = SpotLight();
				Flight = 0;
				m_BasicEffect.SetSpotLight(0, m_FrontLightL);
				m_BasicEffect.SetSpotLight(1, m_FrontLightR);
			}
			//近光灯
			if (ImGui::IsKeyDown('J'))
			{
				m_FrontLightL = m_FrontLight;
				m_FrontLightR = m_FrontLight;
				Flight = 1;
			}
			//远光灯
			if (ImGui::IsKeyDown('K') && Flight == 1)
			{
				m_FrontLightL = m_FrontLight;
				m_FrontLightL.range = 40.0f;
				m_FrontLightR = m_FrontLightL;
				Flight = 2;
			}
			if (Flight == 1 || Flight == 2)
			{
				XMFLOAT3 lightpos = m_fLightL.GetTransform().GetPosition();
				m_FrontLightL.position = XMFLOAT3(lightpos.x, lightpos.y, lightpos.z - 0.5);
				lightpos = m_fLightR.GetTransform().GetPosition();
				m_FrontLightR.position = XMFLOAT3(lightpos.x, lightpos.y, lightpos.z - 0.5);
				m_BasicEffect.SetSpotLight(0, m_FrontLightL);
				m_BasicEffect.SetSpotLight(1, m_FrontLightR);
			}

			//打开后视镜
			static bool OpenMir = false;
			if (ImGui::IsKeyDown('U') || OpenMir == true)
			{
				// 初始化镜面
				Model model;
				model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane(XMFLOAT2(0.5f, 1.0f), XMFLOAT2(1.0f, 1.0f)));
				model.modelParts[0].material.ambient = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
				model.modelParts[0].material.diffuse = XMFLOAT4(0.2f, 0.2f, 0.2f, 0.5f);
				model.modelParts[0].material.specular = XMFLOAT4(0.0f, 0.0f, 0.0f, 2.0f);
				model.modelParts[0].material.reflect = XMFLOAT4(0.6f, 0.6f, 0.6f, 20.0f);
				HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\ice.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
				m_mirrorL.SetModel(std::move(model));
				m_mirrorL.GetTransform().SetRotation(-XM_PIDIV2, 0.0f, 0.0f);
				m_mirrorR = m_mirrorL;
				m_FrameL.GetTransform().SetRotation(0.0f, XM_PIDIV2, 0.0f);
				m_FrameR.GetTransform().SetRotation(0.0f, XM_PIDIV2, 0.0f);

				XMFLOAT3 m1 = m_FrameL.GetTransform().GetPosition();
				XMFLOAT3 m2 = m_FrameR.GetTransform().GetPosition();

				m_mirrorL.GetTransform().SetPosition(m1.x - 1.0f, m1.y, m1.z - 0.1);
				m_mirrorR.GetTransform().SetPosition(m2.x + 1.0f, m2.y, m2.z - 0.1);
				OpenMir = true;
			}
			//关闭后视镜
			if (ImGui::IsKeyDown('I'))
			{
				Model model;
				model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane(XMFLOAT2(0.0f, 0.0f)));
				m_mirrorL.SetModel(std::move(model));;
				m_mirrorR = m_mirrorL;
				m_FrameL.GetTransform().SetRotation(0.0f, 0.0f, 0.0f);
				m_FrameR.GetTransform().SetRotation(0.0f, 0.0f, 0.0f);
				OpenMir = false;
			}
			
		}
		else if (m_CameraMode == CameraMode::Free)
		{
			cam1st->MoveForward(d * 6.0f);
			cam1st->Strafe(d2 * 6.0f);
		}
		// 将摄像机位置限制在[-8.9, 8.9]x[-8.9, 8.9]x[-1.99, 8.9]的区域内
		// 不允许穿地
		XMFLOAT3 adjustedPos;
		XMStoreFloat3(&adjustedPos, XMVectorClamp(cam1st->GetPositionXM(), XMVectorSet(-10000.0f, 0.0f, -10000.0f, 0.0f), XMVectorReplicate(10000.f)));
		cam1st->SetPosition(adjustedPos.x, adjustedPos.y, adjustedPos.z);
		//摄像机的视角旋转
		if (ImGui::IsMouseDragging(ImGuiMouseButton_Right))
		{
			cam1st->Pitch(io.MouseDelta.y * 0.01f);
			cam1st->RotateY(io.MouseDelta.x * 0.01f);
		}
	}

	m_BasicEffect.SetEyePos(m_pCamera->GetPosition());

	m_BasicEffect.SetViewMatrix(m_pCamera->GetViewXM());

	// 重置滚轮值
	m_pMouse->ResetScrollWheelValue();
	if (ImGui::Begin("摄像机"))
	{

		static int curr_item = 0;
		static const char* modes[] = {
			"第三人称",
			"自由视角"
		};
		if (ImGui::Combo("摄像机模式", &curr_item, modes, ARRAYSIZE(modes)))
		{

			if (curr_item == 0 && m_CameraMode != CameraMode::ThirdPerson)
			{


				if (!cam1st)
				{
					cam1st.reset(new FirstPersonCamera);
					cam1st->SetFrustum(XM_PI / 6, AspectRatio(), 1.0f, 50.0f);
					m_pCamera = cam1st;
				}

				XMFLOAT3 pos = m_car.GetTransform().GetPosition();
				XMFLOAT3 to = XMFLOAT3(0.0f, 0.0f, 1.0f);
				XMFLOAT3 up = XMFLOAT3(0.0f, 1.0f, 0.0f);
				pos.y += 4.0;
				cam1st->LookTo(pos, to, up);
				m_CameraMode = CameraMode::ThirdPerson;

			}
			else if (curr_item == 1 && m_CameraMode != CameraMode::Free)
			{

				if (!cam1st)
				{
					cam1st.reset(new FirstPersonCamera);
					cam1st->SetFrustum(XM_PI / 6, AspectRatio(), 1.0f, 50.0f);
					m_pCamera = cam1st;
				}
				// 从箱子上方开始
				XMFLOAT3 pos = m_car.GetTransform().GetPosition();
				XMFLOAT3 to = XMFLOAT3(0.0f, 0.0f, 1.0f);
				XMFLOAT3 up = XMFLOAT3(0.0f, 1.0f, 0.0f);
				pos.y += 4;
				cam1st->LookTo(pos, to, up);
				m_CameraMode = CameraMode::Free;
			}
		}
		auto woodPos = m_FrameL.GetTransform().GetPosition();
		ImGui::Text("车子位置\n%.2f %.2f %.2f", woodPos.x, woodPos.y, woodPos.z);
		auto cameraPos = m_pCamera->GetPosition();
		ImGui::Text("摄像机位置\n%.2f %.2f %.2f", cameraPos.x, cameraPos.y, cameraPos.z);
		ImGui::Text("最高挡位为6");
		ImGui::Text("当前挡位：%.2f", speed);
	}

	// 退出程序，这里应向窗口发送销毁信息
	if (ImGui::IsKeyDown(ImGuiKey_Escape))
		SendMessage(MainWnd(), WM_DESTROY, 0, 0);

	//左上角文字
	ImGui::GetForegroundDrawList()->AddText(m_font, fontsize, ImVec2(m_ClientWidth - m_ClientWidth, m_ClientHeight - m_ClientHeight), ImColor(255, 255, 255, 255), "切换显示:1-法线贴图 2-雾天");
	ImGui::GetForegroundDrawList()->AddText(m_font, fontsize, ImVec2(0, m_ClientWidth - m_ClientWidth + 1 * fontsize), ImColor(255, 255, 255, 255), "车俩主操作:移动:A/W/S/D   进退档:Q/E  引擎开关:F  刹车:SPACE");
	ImGui::GetForegroundDrawList()->AddText(m_font, fontsize, ImVec2(0, m_ClientWidth - m_ClientWidth + 2 * fontsize), ImColor(255, 255, 255, 255), "车俩其他部件：喇叭:R  后视镜:U/I  视角切换:V  灯光:J/K/L");


	ImGui::End();
	ImGui::Render();

}


void GameApp::DrawScene()
{
	assert(m_pd3dImmediateContext);
	assert(m_pSwapChain);

	// ******************
	// 生成动态天空盒
	//

	// 保留当前绘制的渲染目标视图和深度模板视图
	switch (m_SkyBoxMode)
	{
	case SkyBoxMode::Dusk: m_pDusk->Cache(m_pd3dImmediateContext.Get(), m_BasicEffect); break;
	case SkyBoxMode::Afternoon: m_pAfternoon->Cache(m_pd3dImmediateContext.Get(), m_BasicEffect); break;
	case SkyBoxMode::Day: m_pDay->Cache(m_pd3dImmediateContext.Get(), m_BasicEffect); break;
	}

	XMFLOAT3 Cpos=m_car.GetTransform().GetPosition();
	switch (m_SkyBoxMode)
	{
	case SkyBoxMode::Dusk: m_pDusk->BeginCapture(
		m_pd3dImmediateContext.Get(), m_BasicEffect, XMFLOAT3(Cpos.x, Cpos.y+2, Cpos.z), static_cast<D3D11_TEXTURECUBE_FACE>(5)); break;
	case SkyBoxMode::Afternoon: m_pAfternoon->BeginCapture(
		m_pd3dImmediateContext.Get(), m_BasicEffect, XMFLOAT3(Cpos.x, Cpos.y + 2, Cpos.z), static_cast<D3D11_TEXTURECUBE_FACE>(5)); break;
	case SkyBoxMode::Day: m_pDay->BeginCapture(
		m_pd3dImmediateContext.Get(), m_BasicEffect, XMFLOAT3(Cpos.x, Cpos.y + 2, Cpos.z), static_cast<D3D11_TEXTURECUBE_FACE>(5)); break;
	}
	DrawScene(false);

	// 恢复之前的绘制设定
	switch (m_SkyBoxMode)
	{
	case SkyBoxMode::Dusk: m_pDusk->Restore(m_pd3dImmediateContext.Get(), m_BasicEffect, *m_pCamera); break;
	case SkyBoxMode::Afternoon: m_pAfternoon->Restore(m_pd3dImmediateContext.Get(), m_BasicEffect, *m_pCamera); break;
	case SkyBoxMode::Day: m_pDay->Restore(m_pd3dImmediateContext.Get(), m_BasicEffect, *m_pCamera); break;
	}
	// ******************
	// 绘制场景
	//

	// 预先清空
	if(m_FogEnabled)
		m_pd3dImmediateContext->ClearRenderTargetView(m_pRenderTargetView.Get(), reinterpret_cast<const float*>(&Colors::Silver));
	else
		m_pd3dImmediateContext->ClearRenderTargetView(m_pRenderTargetView.Get(), reinterpret_cast<const float*>(&Colors::Black));
	m_pd3dImmediateContext->ClearDepthStencilView(m_pDepthStencilView.Get(), D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

	// 绘制中心球
	DrawScene(true);

	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
	HR(m_pSwapChain->Present(0, 0));
}


bool GameApp::InitResource()
{

	// ******************
	// 初始化法线贴图相关
	//
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\grass_nmap.dds", nullptr, m_GroundNormalMap.GetAddressOf()));
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\road_nmap.dds", nullptr, m_RoadNormalMap.GetAddressOf()));

	// ******************
	// 初始化天空盒相关

	m_pDusk = std::make_unique<DynamicSkyRender>();
	HR(m_pDusk->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),

		L"..\\Texture\\dusk.png",
		5000.0f, 1024));

	m_pAfternoon = std::make_unique<DynamicSkyRender>();
	HR(m_pAfternoon->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),

		L"..\\Texture\\afternoon.png",
		5000.0f, 1024));

	m_pDay = std::make_unique<DynamicSkyRender>();
	HR(m_pDay->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),
			
		L"..\\Texture\\day.png",
		10000.0f,1024));


	m_BasicEffect.SetTextureCube(m_pDay->GetTextureCube());

	// 初始化游戏对象
	//

	Model model;

	// 地面
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane(XMFLOAT2(50.0f, 10000.0f), XMFLOAT2(50.0f, 10000.0f)));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\grass.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Ground.SetModel(std::move(model));
	m_Ground.GetTransform().SetPosition(0.0f, -1.01f, 0.0f);

	// 地面法线贴图
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane<VertexPosNormalTangentTex>(XMFLOAT2(50.0f, 10000.0f), XMFLOAT2(50.0f, 10000.0f)));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\grass.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_GroundT.SetModel(std::move(model));
	m_GroundT.GetTransform().SetPosition(0.0f, -1.01f, 0.0f);

	//公路
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane(XMFLOAT2(20.0f, 10000.0f), XMFLOAT2(2.0f, 500.0f)));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\road.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Road.SetModel(std::move(model));
	m_Road.GetTransform().SetPosition(0.0f, -1.00f, 0.0f);

	//公路法线贴图
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane<VertexPosNormalTangentTex>(XMFLOAT2(20.0f, 10000.0f), XMFLOAT2(2.0f, 500.0f)));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\road.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_RoadT.SetModel(std::move(model));
	m_RoadT.GetTransform().SetPosition(0.0f, -1.00f, 0.0f);

	// 车轮
	model.SetMesh(m_pd3dDevice.Get(),
		Geometry::CreateCylinder(0.5f, 0.3f));
	model.modelParts[0].material.ambient = XMFLOAT4(1.2f,1.2f,1.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\tire2.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_ftyreL.SetModel(std::move(model));
	m_ftyreL.GetTransform().SetPosition(-1.0f, -0.5f, -4790.5f);
	m_ftyreL.GetTransform().SetRotation(0.0f, 0.0f, XM_PIDIV2);
	m_ftyreR = m_ftyreL;
	m_ftyreR.GetTransform().SetRotation(0.0f, 0.0f, XM_PIDIV2);
	//m_ftyre2.GetTransform().SetPosition(1.1f, -0.5f, -20.5f);
	m_btyreL = m_ftyreL;
	m_btyreL.GetTransform().SetRotation(0.0f, 0.0f, XM_PIDIV2);
	m_btyreR = m_ftyreL;
	m_btyreR.GetTransform().SetRotation(0.0f, 0.0f, XM_PIDIV2);
		

	// 后视镜
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(0.1f, 0.20f, 2.0f));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\tire1.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_FrameL.SetModel(std::move(model));
	m_FrameR = m_FrameL;

	// 车身
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(1.8f, 0.8f, 4.0f));
	m_CarMat.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	m_CarMat.diffuse = XMFLOAT4(0.4f, 0.4f, 0.4f, 1.0f);
	m_CarMat.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 8.0f);
	m_CarMat.reflect = XMFLOAT4();

	model.modelParts[0].material = m_CarMat;
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\body.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_car.SetModel(std::move(model));
	m_car.GetTransform().SetPosition(0.0f, 6.0f, 1.0f);


	// 前车灯
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(0.3f, 0.20f, 0.1f));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\light.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_fLightL.SetModel(std::move(model));
	m_fLightR = m_fLightL;

	//后车灯
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(0.3f, 0.20f, 0.1f));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\red.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_bLightL.SetModel(std::move(model));
	m_bLightR = m_bLightL;

	// 前向灯光--光源
	m_FrontLight.direction = XMFLOAT3(0.0f, 0.0f, 1.0f);
	m_FrontLight.ambient = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_FrontLight.diffuse = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_FrontLight.specular = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_FrontLight.att = XMFLOAT3(1.0f, 1.0f, 1.0f);
	m_FrontLight.spot = 5.0f;
	m_FrontLight.range = 15.0f;
	

	// 初始化树
	srand((unsigned)time(nullptr));
	m_ObjReader.Read(L"..\\Model\\tree.mbo", L"..\\Model\\tree.obj");
	m_Trees.SetModel(Model(m_pd3dDevice.Get(), m_ObjReader));
	XMMATRIX S1 = XMMatrixScaling(0.015f, 0.015f, 0.015f);

	BoundingBox treeBox = m_Trees.GetLocalBoundingBox();

	// 让树木底部紧贴地面位于y = -1的平面
	treeBox.Transform(treeBox, S1);
	float Ty1 = -(treeBox.Center.y - treeBox.Extents.y + 1.0f);

	m_Trees.ResizeBuffer(m_pd3dDevice.Get(), 1000);
	m_TreeWorlds.resize(1000);
	for (int i = 0; i < m_TreeWorlds.size(); i++)
	{
		Transform t1 = Transform(XMFLOAT3(0.015, 0.015, 0.015), XMFLOAT3(0.0f, rand() % 360 / 360.0f * XM_2PI, 0.0f), XMFLOAT3(pow(-1, i) * 20.5f, Ty1, -5000 + i * 10));
		m_TreeWorlds[i] = t1;
	}

	// 初始化围栏
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(2, 2,100));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\WireFence.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Fences.SetModel(std::move(model));

	m_Fences.GetLocalBoundingBox().Extents = XMFLOAT3(1.2, 1.2, 110.f);
	BoundingBox FenceBox = m_Fences.GetLocalBoundingBox();
	
	// 让围栏底部紧贴地面位于y = -1的平面
	float Ty2 = -(FenceBox.Center.y - FenceBox.Extents.y + 1.0f);

	m_Fences.ResizeBuffer(m_pd3dDevice.Get(), 200);
	m_FenceWorlds.resize(200);
	m_ISBounding.resize(200);
	for (int i = 0; i < m_FenceWorlds.size(); i++)
	{
		Transform t1 = Transform(XMFLOAT3(1, 1, 1), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(pow(-1, i) * 11, Ty2,-5000+i*50));
		m_FenceWorlds[i] = t1;
		XMMATRIX  S3 = XMMatrixTranslation(pow(-1, i) * 11, Ty2, -5000 + i * 50);
		m_ISBounding[i].Transform(m_ISBounding[i], S3);
		m_ISBounding[i].Extents = XMFLOAT3(1.2,1.2, 110.f);
	}

	// ******************
	// 初始化摄像机
	//
	auto camera = std::shared_ptr<FirstPersonCamera>(new FirstPersonCamera);
	m_pCamera = camera;
	camera->SetViewPort(0.0f, 0.0f, (float)m_ClientWidth, (float)m_ClientHeight);
	camera->SetFrustum(XM_PI/3, AspectRatio(), 1, 1000.0f);
	camera->LookTo(XMFLOAT3(0.0f, 5.0f, -5.0f),
		XMFLOAT3(0.0f, 0.0f, 1.0f),
		XMFLOAT3(0.0f, 1.0f, 0.0f));
	m_CameraMode = CameraMode::ThirdPerson;


	m_BasicEffect.SetViewMatrix(camera->GetViewXM());
	m_BasicEffect.SetProjMatrix(camera->GetProjXM());



	// ******************
	// 初始化不会变化的值
	//

	// 稍微高一点位置以显示阴影
	m_BasicEffect.SetShadowMatrix(XMMatrixShadow(XMVectorSet(0.0f, 1.00f, 0.0f, 0.99f), XMVectorSet(0.577f, 0.577f, -0.577f, 0.0f)));
	
	//雾的初始化
	m_BasicEffect.SetFogState(m_FogEnabled);
	m_BasicEffect.SetFogColor(XMVectorSet(0.75f, 0.75f, 0.75f, 1.0f));//
	m_BasicEffect.SetFogStart(5.0f);
	m_BasicEffect.SetFogRange(75.0f);

	//阴影的材质
	m_ShadowMat.ambient = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
	m_ShadowMat.diffuse = XMFLOAT4(0.0f, 0.0f, 0.0f, 0.5f);
	m_ShadowMat.specular = XMFLOAT4(0.0f, 0.0f, 0.0f, 8.0f);



	// 方向光
	m_dirLight[0].ambient = XMFLOAT4(0.15f, 0.15f, 0.15f, 1.0f);
	m_dirLight[0].diffuse = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	m_dirLight[0].specular = XMFLOAT4(0.1f, 0.1f, 0.1f, 1.0f);
	m_dirLight[0].direction = XMFLOAT3(-0.577f, -0.577f, 0.577f);
	m_dirLight[1] = m_dirLight[0];
	m_dirLight[1].direction = XMFLOAT3(0.577f, -0.577f, 0.577f);
	m_dirLight[2] = m_dirLight[0];
	m_dirLight[2].direction = XMFLOAT3(0.577f, -0.577f, -0.577f);
	m_dirLight[3] = m_dirLight[0];
	m_dirLight[3].direction = XMFLOAT3(-0.577f, -0.577f, -0.577f);
	for (int i = 0; i < 4; ++i)
		m_BasicEffect.SetDirLight(i, m_dirLight[i]);


	// ******************
	// 设置调试对象名
	//
	m_ftyreL.SetDebugObjectName("Cylinder");
	m_Ground.SetDebugObjectName("Ground");
	m_pDusk->SetDebugObjectName("Dusk");
	return true;
}

void GameApp::DrawScene(bool draw)
{

	// 绘制对象
	m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderObject);
	m_BasicEffect.SetTextureUsed(true);

	//是否折射与反射
	if (draw)
	{
		m_BasicEffect.SetRefractionEnabled(false);
		m_BasicEffect.SetReflectionEnabled(true);

		m_mirrorL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
		m_mirrorR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	}
	m_BasicEffect.SetReflectionEnabled(false);
	m_BasicEffect.SetRefractionEnabled(false);

	//是否法线贴图
	if (m_NormalMapEnabled)
	{
		m_BasicEffect.SetRenderWithNormalMap(m_pd3dImmediateContext.Get(), BasicEffect::RenderObject);
		m_BasicEffect.SetTextureNormalMap(m_GroundNormalMap.Get());
		m_GroundT.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
		m_BasicEffect.SetTextureNormalMap(m_RoadNormalMap.Get());
		m_RoadT.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
		m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderObject);
	}
	else
	{
		m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderObject);
		m_Road.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
		m_Ground.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	}

	m_ftyreL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_ftyreR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_btyreL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_btyreR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_fLightL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_fLightR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_bLightL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_bLightR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);

	m_FrameL.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_FrameR.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_car.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);

	// ******************
	// 6. 绘制不透明正常物体的阴影
	m_car.GetModel().modelParts[0].material = m_ShadowMat;
	m_BasicEffect.SetShadowState(true);	// 反射关闭，阴影开启
	m_car.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_BasicEffect.SetShadowState(false);		// 阴影关闭
	m_car.GetModel().modelParts[0].material = m_CarMat;

	//视锥体裁剪
	// 统计实际绘制的物体数目
	std::vector<Transform> acceptedData;
	acceptedData = Collision::FrustumCulling(m_TreeWorlds, m_Trees.GetLocalBoundingBox(),
		m_pCamera->GetViewXM(), m_pCamera->GetProjXM());

	m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderInstance);
	m_Trees.DrawInstanced(m_pd3dImmediateContext.Get(), m_BasicEffect, acceptedData);

	//改变围栏的包围盒
	BoundingBox FenceBox = m_Fences.GetLocalBoundingBox();
	FenceBox.Extents = XMFLOAT3(1.2, 1.2, 110);
	acceptedData = Collision::FrustumCulling(m_FenceWorlds, FenceBox,
		m_pCamera->GetViewXM(), m_pCamera->GetProjXM());

	m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderInstance);
	m_Fences.DrawInstanced(m_pd3dImmediateContext.Get(), m_BasicEffect, acceptedData);

	//不是雾天或黑夜绘制天空盒
	if (m_FogEnabled==false&& m_IsNight==false)
	{
		// 绘制天空盒
		m_SkyEffect.SetRenderDefault(m_pd3dImmediateContext.Get());
		switch (m_SkyBoxMode)
		{
		case SkyBoxMode::Dusk: m_pDusk->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, (draw ? *m_pCamera : m_pDusk->GetCamera())); break;
		case SkyBoxMode::Afternoon: m_pAfternoon->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, (draw ? *m_pCamera : m_pAfternoon->GetCamera())); break;
		case SkyBoxMode::Day: m_pDay->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, (draw ? *m_pCamera : m_pDay->GetCamera())); break;
		}
	}


}

