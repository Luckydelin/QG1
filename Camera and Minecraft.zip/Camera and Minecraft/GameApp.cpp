#include "GameApp.h"
#include "d3dUtil.h"
#include "DXTrace.h"
using namespace DirectX;

GameApp::GameApp(HINSTANCE hInstance)
	: D3DApp(hInstance),
	m_CameraMode(CameraMode::Free),
	m_SkyBoxMode(SkyBoxMode::Daylight)
{
	
}

GameApp::~GameApp()
{
}

bool GameApp::Init()
{
	if (!D3DApp::Init())
		return false;

	// 务必先初始化所有渲染状态，以供下面的特效使用
	RenderStates::InitAll(m_pd3dDevice.Get());

	if (!m_BasicEffect.InitAll(m_pd3dDevice.Get()))
		return false;

	if (!m_SkyEffect.InitAll(m_pd3dDevice.Get()))
		return false;

	if (!InitResource())
		return false;

	// 初始化鼠标，键盘不需要
	m_pMouse->SetWindow(m_hMainWnd);
	m_pMouse->SetMode(DirectX::Mouse::MODE_ABSOLUTE);

	return true;
}

void GameApp::OnResize()
{
	

	D3DApp::OnResize();


	// 摄像机变更显示
	if (m_pCamera != nullptr)
	{
		m_pCamera->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
		m_pCamera->SetViewPort(0.0f, 0.0f, (float)m_ClientWidth, (float)m_ClientHeight);
		m_BasicEffect.SetProjMatrix(m_pCamera->GetProjXM());
	}

}

void GameApp::UpdateScene(float dt)
{
	
	
		ImGuiIO& io = ImGui::GetIO();

		//获取摄像机子类

		auto cam3rd = std::dynamic_pointer_cast<ThirdPersonCamera>(m_pCamera);

		auto cam1st = std::dynamic_pointer_cast<FirstPersonCamera>(m_pCamera);

		float fontsize = 30.0f;//字体大小

		Ray ray = Ray::ScreenToRay(*cam1st, (float)io.MouseDelta.x, (float)io.MouseDelta.y);

		// ******************
		// 拾取检测
		//是否碰到物体默认为false
		bool hitObject= false;
		
		// 重置滚轮值
		m_pMouse->ResetScrollWheelValue();
		if (ImGui::Begin("摄像机"))
		{

			static int curr_item = 0;
			static const char* modes[] = {
				"第一人称",
				"第三人称",
				"自由视角"
			};
			if (ImGui::Combo("摄像机模式", &curr_item, modes, ARRAYSIZE(modes)))
			{

				if (curr_item == 0 && m_CameraMode != CameraMode::FirstPerson)
				{
					
					
					if (!cam1st)
					{
						cam1st.reset(new FirstPersonCamera);
						cam1st->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
						m_pCamera = cam1st;
					}

					cam1st->LookTo(m_WoodCrate.GetTransform().GetPosition(),
						XMFLOAT3(0.0f, 0.0f, 1.0f),
						XMFLOAT3(0.0f, 1.0f, 0.0f));

					m_CameraMode = CameraMode::FirstPerson;
					
				}
				else if (curr_item == 1 && m_CameraMode != CameraMode::ThirdPerson)
				{
					/*ray = Ray();
					if (!cam3rd)
					{
						cam3rd.reset(new ThirdPersonCamera);
						cam3rd ->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
						m_pCamera = cam3rd;
					}
					XMFLOAT3 target = m_WoodCrate.GetTransform().GetPosition();
					cam3rd->SetTarget(target);
					cam3rd->SetDistance(1.0f);
					cam3rd->SetDistanceMinMax(1.0f, 2.0f);*/
					m_CameraMode = CameraMode::ThirdPerson;

				}
				else if (curr_item == 2 && m_CameraMode != CameraMode::Free)
				{
					
					if (!cam1st)
					{
						cam1st.reset(new FirstPersonCamera);
						cam1st->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
						m_pCamera = cam1st;
					}
					// 从箱子上方开始
					XMFLOAT3 pos = m_WoodCrate.GetTransform().GetPosition();
					XMFLOAT3 to = XMFLOAT3(0.0f, 0.0f, 1.0f);
					XMFLOAT3 up = XMFLOAT3(0.0f, 1.0f, 0.0f);
					pos.y += 3.;
					cam1st->LookTo(pos, to, up);

					m_CameraMode = CameraMode::Free;
					ImGui::Text("移动：UP/DOWN/LEFT/RIGHT");
				}
			}

			auto woodPos = m_WoodCrate.GetTransform().GetPosition();

			ImGui::Text("盒子位置\n%.2f %.2f %.2f", woodPos.x, woodPos.y, woodPos.z);
			auto cameraPos = m_pCamera->GetPosition();
			ImGui::Text("摄像机位置\n%.2f %.2f %.2f", cameraPos.x, cameraPos.y, cameraPos.z);
		}

		if (m_CameraMode == CameraMode::FirstPerson || m_CameraMode == CameraMode::Free)
		{
			
			///放置物块
			if (io.MouseDown[0] == true)//== Mouse::ButtonStateTracker::PRESSED
			{
				Model model;
				model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(0.3f, 0.3f, 0.3f));
				model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
				model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
				model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
				model.modelParts[0].material.reflect = XMFLOAT4();
				HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\WoodCrate.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
				m_Cylinder2.SetModel(std::move(model));
				m_Cylinder2.GetTransform().SetPosition(cam1st->GetPosition().x , 
					-2.84f, cam1st->GetPosition().z+cam1st->m_Transform.GetForwardAxis().z*3);

				m_BoundingBox.Center = m_Cylinder2.GetTransform().GetPosition();
				m_BoundingBox.Extents = XMFLOAT3(1.0f, 1.0f, 1.0f);
				
			}
			//碰到或击中物体
			if (ray.Hit(m_BoundingBox))
			{
				hitObject= true;
			}
			else
			{
				hitObject = false;
			}
			//碰到则高亮物体
			if (hitObject == true)
			{

				m_HighLight.position = m_Cylinder2.GetTransform().GetPosition();
				m_HighLight.ambient = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_HighLight.diffuse = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_HighLight.specular = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				m_HighLight.att = XMFLOAT3(1.0f, 1.1f, 1.0f);
				m_HighLight.range = 10.0f;
				m_BasicEffect.SetPointLight(0, m_HighLight);
			}
			//否则不高亮
			else if (hitObject != true)
			{
				m_HighLight = PointLight();
				m_BasicEffect.SetPointLight(0, m_HighLight);
			}

			if (io.MouseDown[1] == true && hitObject == true)
			{
				Model model;
				model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateBox(0.0f, 0.0f, 0.0f));
				/*HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), L"..\\Texture\\WoodCrate.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));*/
				m_Cylinder2.SetModel(std::move(model));
				m_Cylinder2.GetTransform().SetPosition(cam1st->GetPosition().x - cam1st->m_Transform.GetRightAxis().x,
					-2.84f, cam1st->GetPosition().z + cam1st->m_Transform.GetForwardAxis().z * 3);
				m_BoundingBox.Center = m_Cylinder2.GetTransform().GetPosition();
				m_BoundingBox.Extents = XMFLOAT3(0.0f, 0.0f, 0.0f);
				hitObject = false;
			}
				
			if (m_CameraMode == CameraMode::FirstPerson)
			{
				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth- 12 * fontsize, m_ClientWidth - m_ClientWidth +1 * fontsize),
					ImColor(255, 255, 255, 255), "盒子仅在第一人称模式下移动");

				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth - 11 * fontsize, m_ClientWidth - m_ClientWidth +2 * fontsize),
					ImColor(255, 255, 255, 255), "移动：UP/DOWN/LEFT/RIGHT");

				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth -6* fontsize, m_ClientWidth - m_ClientWidth + 3 * fontsize),
					ImColor(255, 255, 255, 255), "旋转:移动鼠标");
				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth - 13 * fontsize, m_ClientWidth - m_ClientWidth + 0 * fontsize),
					ImColor(255, 255, 255, 255), "鼠标左键生成方块，右键销毁方块");
			}
			else
			{

				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth - 11 * fontsize, m_ClientWidth - m_ClientWidth + 1 * fontsize),
					ImColor(255, 255, 255, 255), "移动：UP/DOWN/LEFT/RIGHT");

				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth - 6 * fontsize, m_ClientWidth - m_ClientWidth +2 * fontsize),
					ImColor(255, 255, 255, 255), "旋转:移动鼠标");
				ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
					ImVec2(m_ClientWidth - 13 * fontsize, m_ClientWidth - m_ClientWidth + 0* fontsize),
					ImColor(255, 255, 255, 255), "鼠标左键生成方块，右键销毁方块");
			}
			

			

			// 第一人称/自由摄像机的操作
			float d1 = 0.0f, d2 = 0.0f;
			if (ImGui::IsKeyDown('W'))
				d1 += dt;
			if (ImGui::IsKeyDown('S'))
				d1 -= dt;
			if (ImGui::IsKeyDown('A'))
				d2 -= dt;
			if (ImGui::IsKeyDown('D'))
				d2 += dt;

			if (m_CameraMode == CameraMode::FirstPerson)
				cam1st->Walk(d1 * 6.0f);
			else
				cam1st->MoveForward(d1 * 6.0f);
			cam1st->Strafe(d2 * 6.0f);

			// 将摄像机位置限制在[-8.9, 8.9]x[-8.9, 8.9]x[-1.8, 8.9]的区域内//-8.9f, -1.8f, -8.9f, +2.0f
			// 不允许穿地
			if (m_CameraMode == CameraMode::FirstPerson)
			{
				XMFLOAT3 adjustedPos;
				XMStoreFloat3(&adjustedPos, XMVectorClamp(cam1st->GetPositionXM(), XMVectorSet(-8.9f, -1.8f, -8.9f, +2.0f), XMVectorReplicate(8.9f)));
				cam1st->SetPosition(adjustedPos);
				m_WoodCrate.GetTransform().SetPosition(adjustedPos);
			}

			cam1st->Pitch(io.MouseDelta.y * 0.01f);
			cam1st->RotateY(io.MouseDelta.x * 0.01f);
			
		}
		else if (m_CameraMode == CameraMode::ThirdPerson)
		{
			
			ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
				ImVec2(0, m_ClientWidth - m_ClientWidth + 2 * fontsize),
				ImColor(255, 255, 255, 255), "第三人称无任何操作");

			/*ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
				ImVec2(0, m_ClientWidth - m_ClientWidth + 1 * fontsize),
				ImColor(255, 255, 255, 255), "按住鼠标右键并拖动视图");*/
			// 第三人称摄像机的操作
			// 绕物体旋转
			/*if (ImGui::IsMouseDragging(ImGuiMouseButton_Right))
			{
				cam3rd->RotateX(io.MouseDelta.y * 0.01f);
				cam3rd->RotateY(io.MouseDelta.x * 0.01f);
			}
			cam3rd->Approach(-io.MouseWheel * 1.0f);*/
		}

		m_BasicEffect.SetEyePos(m_pCamera->GetPosition());//	/

		m_BasicEffect.SetViewMatrix(m_pCamera->GetViewXM());
		

		ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
			ImVec2(0, m_ClientWidth - m_ClientWidth + 0 * fontsize),
			ImColor(255, 255, 255, 255), "切换天空盒：1-落日，2-湖，3-长空");

		ImGui::GetForegroundDrawList()->AddText(m_font, fontsize,
			ImVec2(0, m_ClientWidth - m_ClientWidth + 1 * fontsize),
			ImColor(255, 255, 255, 255), "靠近物体会高亮，此时可销毁");
	
		//// 选择天空盒
		if (ImGui::IsKeyDown('1'))
		{
			m_SkyBoxMode = SkyBoxMode::Daylight;
			m_BasicEffect.SetTextureCube(m_pDask->GetTextureCube());
		}
		if (ImGui::IsKeyDown('2'))
		{
			m_SkyBoxMode = SkyBoxMode::Sunset;
			m_BasicEffect.SetTextureCube(m_pLake->GetTextureCube());
		}
		if (ImGui::IsKeyDown('3'))
		{
			m_SkyBoxMode = SkyBoxMode::Desert;
			m_BasicEffect.SetTextureCube(m_pSky->GetTextureCube());
		}

		
		ImGui::End();
		ImGui::Render();
		 
}

void GameApp::DrawScene()
{
	assert(m_pd3dImmediateContext);
	assert(m_pSwapChain);

	// ******************
	// 绘制Direct3D部分
	//
	m_pd3dImmediateContext->ClearRenderTargetView(m_pRenderTargetView.Get(), reinterpret_cast<const float*>(&Colors::Black));
	m_pd3dImmediateContext->ClearDepthStencilView(m_pDepthStencilView.Get(), D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

	// 绘制模型
	m_BasicEffect.SetRenderDefault(m_pd3dImmediateContext.Get(), BasicEffect::RenderObject);
	m_BasicEffect.SetReflectionEnabled(true);
	m_BasicEffect.SetTextureUsed(true);
	m_Sphere.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);

	m_BasicEffect.SetReflectionEnabled(false);
	m_Ground.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_Cylinder1.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_Cylinder2.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);
	m_WoodCrate.Draw(m_pd3dImmediateContext.Get(), m_BasicEffect);

	// 绘制天空盒
	m_SkyEffect.SetRenderDefault(m_pd3dImmediateContext.Get());
	switch (m_SkyBoxMode)
	{
	case SkyBoxMode::Daylight: m_pDask->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, *m_pCamera); break;
	case SkyBoxMode::Sunset: m_pLake->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, *m_pCamera); break;
	case SkyBoxMode::Desert: m_pSky->Draw(m_pd3dImmediateContext.Get(), m_SkyEffect, *m_pCamera); break;
	}


	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	HR(m_pSwapChain->Present(0, 0));
}



bool GameApp::InitResource()
{
	// ******************
	// 初始化天空盒相关

	m_pDask = std::make_unique<SkyRender>();
	HR(m_pDask->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),
		L"..\\Texture\\texture2.png", 
		5000.0f));

	m_pLake = std::make_unique<SkyRender>();
	HR(m_pLake->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),
		std::vector<std::wstring>{
		L"..\\Texture\\1x.jpg", L"..\\Texture\\1-x.jpg",
			L"..\\Texture\\1y.jpg", L"..\\Texture\\1-y.jpg",
			L"..\\Texture\\1z.jpg", L"..\\Texture\\1-z.jpg", },
		5000.0f));

	m_pSky = std::make_unique<SkyRender>();
	HR(m_pSky->InitResource(m_pd3dDevice.Get(), m_pd3dImmediateContext.Get(),
		L"..\\Texture\\texture1.dds",
		5000.0f));

	m_BasicEffect.SetTextureCube(m_pDask->GetTextureCube());
	// ******************desertcube1024
	// 初始化游戏对象
	//
	
	Model model;
	// 球体
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreateSphere(1.0f, 30, 30));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.8f, 0.8f, 0.8f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(), 
		L"..\\Texture\\stone.dds", 
		nullptr, 
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Sphere.SetModel(std::move(model));
	// 地面
	model.SetMesh(m_pd3dDevice.Get(), Geometry::CreatePlane(XMFLOAT2(10.0f, 10.0f), XMFLOAT2(5.0f, 5.0f)));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f); 
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\floor.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Ground.SetModel(std::move(model));
	m_Ground.GetTransform().SetPosition(0.0f, -3.0f, 0.0f);
	// 柱体
	model.SetMesh(m_pd3dDevice.Get(),
		Geometry::CreateCylinder(0.5f, 2.0f));
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),
		L"..\\Texture\\bricks.dds",
		nullptr,
		model.modelParts[0].texDiffuse.GetAddressOf()));
	m_Cylinder1.SetModel(std::move(model));
	m_Cylinder1.GetTransform().SetPosition(0.0f, -1.99f, 0.0f);

	//木盒子
	model.SetMesh(m_pd3dDevice.Get(),Geometry::CreateBox());
	model.modelParts[0].material.ambient = XMFLOAT4(0.2f, 0.2f, 0.2f, 1.0f);
	model.modelParts[0].material.diffuse = XMFLOAT4(0.8f, 0.8f, 0.8f, 1.0f);
	model.modelParts[0].material.specular = XMFLOAT4(0.2f, 0.2f, 0.2f, 16.0f);
	model.modelParts[0].material.reflect = XMFLOAT4();
	HR(CreateDDSTextureFromFile(m_pd3dDevice.Get(),L"..\\Texture\\WoodCrate.dds", nullptr, model.modelParts[0].texDiffuse.GetAddressOf()));
	m_WoodCrate.SetModel(std::move(model));
	m_WoodCrate.GetTransform().SetPosition(0.0f, -2.0f,2.0f );

	

	// ******************
	// 初始化摄像机
	//
	auto camera = std::shared_ptr<FirstPersonCamera>(new FirstPersonCamera);
	m_pCamera = camera;
	camera->SetViewPort(0.0f, 0.0f, (float)m_ClientWidth, (float)m_ClientHeight);
	camera->SetFrustum(XM_PI / 3, AspectRatio(), 1.0f, 1000.0f);
	camera->LookTo(XMFLOAT3(0.0f, -1.99f, -2.0f),
		XMFLOAT3(0.0f, 0.0f,2.0f),
		XMFLOAT3(0.0f, 1.0f, 0.0f));
	m_CameraMode = CameraMode::FirstPerson;
	

	m_BasicEffect.SetViewMatrix(camera->GetViewXM());
	m_BasicEffect.SetProjMatrix(camera->GetProjXM());


	// ******************
	// 初始化不会变化的值
	//

	// 方向光
	DirectionalLight dirLight[4];
	dirLight[0].ambient = XMFLOAT4(0.15f, 0.15f, 0.15f, 1.0f);
	dirLight[0].diffuse = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	dirLight[0].specular = XMFLOAT4(0.1f, 0.1f, 0.1f, 1.0f);
	dirLight[0].direction = XMFLOAT3(-0.577f, -0.577f, 0.577f);
	dirLight[1] = dirLight[0];
	dirLight[1].direction = XMFLOAT3(0.577f, -0.577f, 0.577f);
	dirLight[2] = dirLight[0];
	dirLight[2].direction = XMFLOAT3(0.577f, -0.577f, -0.577f);
	dirLight[3] = dirLight[0];
	dirLight[3].direction = XMFLOAT3(-0.577f, -0.577f, -0.577f);
	for (int i = 0; i < 4; ++i)
		m_BasicEffect.SetDirLight(i, dirLight[i]);

	

	// ******************
	// 设置调试对象名
	//
	m_Cylinder1.SetDebugObjectName("Cylinder");
	m_Ground.SetDebugObjectName("Ground");
	m_Sphere.SetDebugObjectName("Sphere");
	m_pDask->SetDebugObjectName("DayLight");
	m_pLake->SetDebugObjectName("Sunset");
	m_pSky->SetDebugObjectName("Desert");
	return true;
}

