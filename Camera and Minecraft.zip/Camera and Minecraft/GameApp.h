#ifndef GAMEAPP_H
#define GAMEAPP_H

#include "d3dApp.h"
#include "Camera.h"
#include "GameObject.h"
#include "SkyRender.h"
#include "ObjReader.h"
#include "Collision.h"

#include <vector>
class GameApp : public D3DApp
{
public:


	struct CBChangesEveryFrame
	{
		DirectX::XMMATRIX view;
		DirectX::XMFLOAT4 eyePos;
		//float g_Pad2;
	};


public:
	// 摄像机模式
	enum class CameraMode { FirstPerson, ThirdPerson, Free };
	// 天空盒模式
	enum class SkyBoxMode { Daylight, Sunset, Desert };

public:
	GameApp(HINSTANCE hInstance);
	~GameApp();

	bool Init();
	void OnResize();
	void UpdateScene(float dt);
	void DrawScene();

private:
	bool InitResource();
	
private:
	
	ComPtr<ID2D1SolidColorBrush> m_pColorBrush;				    // 单色笔刷
	ComPtr<IDWriteFont> m_pFont;								// 字体
	ComPtr<IDWriteTextFormat> m_pTextFormat;					// 文本格式

	GameObject m_Sphere;										// 球
	GameObject m_Ground;										// 地面
	GameObject m_Cylinder1;									    // 圆柱
	
	GameObject m_WoodCrate;



	BasicEffect m_BasicEffect;								    // 对象渲染特效管理
	
	SkyEffect m_SkyEffect;									    // 天空盒特效管理
	std::unique_ptr<SkyRender> m_pDask;					    // 天空盒(黄昏)
	std::unique_ptr<SkyRender> m_pLake;						// 天空盒(湖)
	std::unique_ptr<SkyRender> m_pSky;						// 天空盒(长空)
	SkyBoxMode m_SkyBoxMode;									// 天空盒模式

	std::shared_ptr<Camera> m_pCamera;						    // 摄像机
	CameraMode m_CameraMode;									// 摄像机模式

	ObjReader m_ObjReader;									    // 模型读取对象

	CBChangesEveryFrame m_CBFrame;							    // 该缓冲区存放仅在每一帧进行更新的变量

	ComPtr<ID3D11Buffer> m_pConstantBuffers[4];				    // 常量缓冲区

	//std::shared_ptr<Camera> m_pCamera;
	std::wstring m_PickedObjStr;

	GameObject m_Cylinder2;								//方块
	DirectX::BoundingBox m_BoundingBox;				    // 方块的包围盒
	PointLight m_HighLight;						// 高亮光
};


#endif